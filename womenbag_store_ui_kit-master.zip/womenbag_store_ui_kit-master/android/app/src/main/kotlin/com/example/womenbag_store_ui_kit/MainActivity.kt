package com.example.womenbag_store_ui_kit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
