class Categories {
  final String name, svgSrc;

  Categories(this.name, this.svgSrc);
}

List catogories = [
  Categories('Watche', 'assets/watch.svg'),
  Categories('Jewellery', 'assets/jewllery.svg'),
  Categories('Dress', 'assets/dress.svg'),
  Categories('Cosmetics', 'assets/cosmetic.svg'),
];
